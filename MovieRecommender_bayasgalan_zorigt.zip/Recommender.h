#ifndef RECOMMENDER_H
#define RECOMMENDER_H

#include "IRecommender.h"
#include "User.h"
#include "Movie.h"

#include <vector>

 
class Recommender : public IRecommender {

private:

    /** @brief List of all movies available in the system. */
    std::vector<Movie> _movies;

    /** @brief List of registered users in the system. */
    std::vector<User> _users;

public:

    /**
     * @brief Retrieves the list of users.
     * @return Reference to internal vector of User objects.
     */
    std::vector<User>& getUsers();

    /**
     * @brief Retrieves the list of movies.
     * @return Reference to internal vector of Movie objects.
     */
    std::vector<Movie>& getMovies();

    /**
     * @brief Loads movies from a CSV file.
     * 
     * Expected format: id, name, genre, rating  
     * Handles quoted movie titles containing commas.
     * 
     * @param filename Path to the CSV file.
     */
    void loadMovies(const std::string& filename);

    /**
     * @brief Loads users into the system.
     * 
     * Default implementation loads no users.
     * Intended for later extension (e.g., loading from file).
     */
    void loadUsers();

    /**
     * @brief Adds a new user to the recommender system.
     * 
     * Ensures the user ID is unique before inserting.
     * 
     * @param name Name of the user.
     * @param id Unique identifier for the user.
     */
    void addUser(const std::string& name, int id);

    /**
     * @brief Generates movie recommendations for a user.
     * 
     * Uses similarity scoring on movies the user has rated.
     * Returns up to the top 5 recommended movies.
     *
     * @param userId ID of the target user.
     * @return Vector of recommended Movie objects.
     */
    std::vector<Movie> recommendForUser(int userId) const override;

    /**
     * @brief Displays recommendations for the given user.
     * 
     * Calls recommendForUser() and prints movie info
     * using Movie::displayInfo().
     * 
     * @param userId ID of the user.
     */
    void displayRecommendations(int userId) const override;
};

#endif // RECOMMENDER_H
