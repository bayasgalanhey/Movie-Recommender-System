#include "Recommender.h"
#include "Movie.h"
#include "User.h"

#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

/**
 * @brief Returns a reference to the internal list of users.
 * @return Vector of User objects stored in the recommender.
 */
vector<User>& Recommender::getUsers() {
    return _users;
}

/**
 * @brief Returns a reference to the internal list of movies.
 * @return Vector of Movie objects stored in the recommender.
 */
vector<Movie>& Recommender::getMovies()  {
    return _movies;
}

/**
 * @brief Loads movies from a CSV file and stores them in the recommender.
 * 
 * The CSV must contain: id, name, genre, rating.
 * Handles movie titles that contain commas inside quotes.
 * 
 * @param filename The path to the CSV file.
 */
void Recommender::loadMovies(const string& filename) {

    ifstream file(filename);
    if (!file.is_open()) {
        cout << "Error: Could not open movie file: " << filename << endl;
        return;
    }

    string line;
    string header;

    // Skip header line
    getline(file, header);

    while (getline(file, line)) {

        // Extract columns with proper handling of quoted titles
        vector<string> cols;
        string temp = "";
        bool insideQuotes = false;

        for (size_t i = 0; i < line.size(); i++) {
            char c = line[i];

            if (c == '"') {
                insideQuotes = !insideQuotes;
            }
            else if (c == ',' && !insideQuotes) {
                cols.push_back(temp);
                temp = "";
            }
            else {
                temp += c;
            }
        }

        cols.push_back(temp);

        // Expecting exactly 4 columns: id, name, genre, rating
        if (cols.size() != 4) {
            continue;
        }

        int id = stoi(cols[0]);
        string name = cols[1];
        string genre = cols[2];
        double rating = stod(cols[3]);

        _movies.push_back(Movie(id, name, genre, rating));
    }

    file.close();
    cout << "Loaded " << _movies.size() << " movies." << endl;
}

/**
 * @brief Loads a small set of default users for testing.
 * 
 * Creates two test users and assigns them a few movie ratings.
 */
void Recommender::loadUsers() {

    User u1("Alice", 99);
    User u2("Bob", 98);

    u1.rateMovie(1, 9.2);
    u1.rateMovie(5, 8.4);

    u2.rateMovie(2, 7.5);
    u2.rateMovie(5, 9.1);

    _users.push_back(u1);
    _users.push_back(u2);

    cout << "Users loaded: " << _users.size() << endl;
}

/**
 * @brief Adds a new user to the recommender.
 * 
 * Checks if the user ID already exists before inserting.
 * 
 * @param name The name of the new user.
 * @param id Unique identifier for the user.
 */
void Recommender::addUser(const string& name, int id) {

    for (size_t i = 0; i < _users.size(); i++) {
        if (_users[i].getID() == id) {
            cout << "Error: User ID already exists." << endl;
            return;
        }
    }

    User newUser(name, id);
    _users.push_back(newUser);

    cout << "User " << name << " added successfully!" << endl;
}

/**
 * @brief Generates movie recommendations for a user.
 * 
 * Uses similarity scores to all movies the user has rated, then sorts 
 * and returns the top 5 highest-scoring recommendations.
 * 
 * @param userId The ID of the user for whom to generate recommendations.
 * @return A vector of Movie objects recommended for the user.
 */
vector<Movie> Recommender::recommendForUser(int userId) const {

    vector<Movie> recommendations;

    // Locate target user
    const User* targetUser = NULL;

    for (size_t i = 0; i < _users.size(); i++) {
        if (_users[i].getID() == userId) {
            targetUser = &_users[i];
            break;
        }
    }

    if (targetUser == NULL) {
        cout << "User not found!" << endl;
        return recommendations;
    }

    vector<pair<int, double> > userRatings = targetUser->getRatedMovies();

    // Score each movie the user has NOT rated
    vector<pair<double, Movie> > scoredMovies;

    for (size_t i = 0; i < _movies.size(); i++) {

        Movie candidate = _movies[i];

        // Skip movies already rated
        bool already = false;
        for (size_t j = 0; j < userRatings.size(); j++) {
            if (userRatings[j].first == candidate.getID()) {
                already = true;
                break;
            }
        }
        if (already) continue;

        double score = 0.0;

        // Compute similarity to each movie the user rated
        for (size_t j = 0; j < userRatings.size(); j++) {
            int ratedId = userRatings[j].first;

            for (size_t k = 0; k < _movies.size(); k++) {
                if (_movies[k].getID() == ratedId) {
                    score += candidate.similarityTo(_movies[k]);
                }
            }
        }

        scoredMovies.push_back(pair<double, Movie>(score, candidate));
    }

    // Bubble sort by highest score first
    for (size_t i = 0; i + 1 < scoredMovies.size(); i++) {
        for (size_t j = 0; j + 1 < scoredMovies.size() - i; j++) {
            if (scoredMovies[j].first < scoredMovies[j + 1].first) {
                pair<double, Movie> temp = scoredMovies[j];
                scoredMovies[j] = scoredMovies[j + 1];
                scoredMovies[j + 1] = temp;
            }
        }
    }

    // Limit to top 5 recommendations
    size_t limit = min((size_t)5, scoredMovies.size());
    for (size_t i = 0; i < limit; i++) {
        recommendations.push_back(scoredMovies[i].second);
    }

    return recommendations;
}

/**
 * @brief Prints movie recommendations for the given user.
 * 
 * Displays up to 5 recommended movies using Movie::displayInfo().
 * 
 * @param userId The ID of the user whose recommendations to display.
 */
void Recommender::displayRecommendations(int userId) const {

    vector<Movie> recs = recommendForUser(userId);

    cout << "Recommended movies for user " << userId << ":" << endl;

    if (recs.size() == 0) {
        cout << "No recommendations available." << endl;
        return;
    }

    for (size_t i = 0; i < recs.size(); i++) {
        recs[i].displayInfo();
    }
}
